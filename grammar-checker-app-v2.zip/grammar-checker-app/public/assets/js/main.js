document.addEventListener('DOMContentLoaded', function() {
    const textInput = document.getElementById('text-input');
    const charCounter = document.getElementById('counter');
    const checkButton = document.getElementById('check-btn');
    const saveButton = document.getElementById('save-btn');
    const correctedTextDiv = document.getElementById('corrected-text');
    const languageSelect = document.getElementById('language-select');
    
    // Лічильник символів
    textInput.addEventListener('input', () => {
        charCounter.innerText = `Characters: ${textInput.value.length}/5000`;
    });

    // Подія на кнопку Check Text
    checkButton.addEventListener('click', () => {
        const text = textInput.value;

        // Якщо поле введення не порожнє, копіюємо текст у нижню область
        if (text.length > 0) {
            correctedTextDiv.innerText = text;
        } else {
            alert("Please enter some text.");
        }
    });

    // Збереження результату в локальне сховище
    saveButton.addEventListener('click', () => {
        const correctedText = correctedTextDiv.innerText;
        if (correctedText) {
            localStorage.setItem('correctedText', correctedText);
            alert("Text saved!");
        } else {
            alert("Nothing to save.");
        }
    });
});
